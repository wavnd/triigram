sap.ui.define([], function () {
	"use strict";

	return {
		formatDate: function(date){
			return date;
		}
	};
});